"""
Module for creating a graphical user interface to train models on bean data.
"""

import tkinter as tk
from tkinter import filedialog, messagebox, Label, Button, Radiobutton, StringVar
import beansmlp
import beanslr


def select_file():
    """
    Open a file dialog to select a CSV file and update the file path label.
    Enable the train button if a file is selected.
    """
    filepath = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if filepath:
        file_path_label.config(text=filepath)
        train_button.config(state='normal')


def train_model():
    """
    Train the selected model (MLP or Logistic Regression) on the selected CSV file
    and display the training results in a message box.
    """
    model_choice = model_var.get()
    filepath = file_path_label.cget("text")
    if model_choice == 'MLP':
        result = beansmlp.load_and_train_mlp(filepath)
    else:
        result = beanslr.load_and_train_lr(filepath)
    messagebox.showinfo("Model Training Results", result)


root = tk.Tk()
root.title("Model Training Interface")

model_var = StringVar(value="LR")

Label(root, text="Select Model:").pack()
Radiobutton(root, text="Logistic Regression", variable=model_var, value="LR").pack()
Radiobutton(root, text="MLP", variable=model_var, value="MLP").pack()

Label(root, text="Select CSV File:").pack()
file_path_label = Label(root, text="No file selected")
file_path_label.pack()
Button(root, text="Browse", command=select_file).pack()

train_button = Button(root, text="Train Model", command=train_model, state='disabled')
train_button.pack()

root.mainloop()
