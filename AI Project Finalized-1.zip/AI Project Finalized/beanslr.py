"""
Module for training a logistic regression model on bean data.
"""

import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report


def load_and_train_lr(filepath):
    """
    Load data from CSV file, preprocess it, train a logistic regression model,
    and return the model's accuracy and classification report.

    Args:
        filepath (str): Path to the CSV file containing the bean data.

    Returns:
        str: A string containing the model's accuracy and classification report.
    """
    df = pd.read_csv(filepath)

    if df is not None:
        le = LabelEncoder()
        df['Class Encoded'] = le.fit_transform(df['Class'])

        features = df.iloc[:, :-2]
        target = df.iloc[:, -1]
        X_train, X_test, y_train, y_test = train_test_split(
            features, target, test_size=0.2, random_state=42
        )

        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

        model = LogisticRegression(multi_class='multinomial', solver='lbfgs')
        model.fit(X_train, y_train)

        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        report = classification_report(y_test, y_pred)
        return f"Accuracy: {accuracy:.2%}\n\n{report}"
